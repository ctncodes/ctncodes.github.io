
// declare variables here


// setup runs once
function setup() {
	createCanvas(500, 500);
	background(150);
}

// draw loops and loops
function draw() {

}


// write functions here
